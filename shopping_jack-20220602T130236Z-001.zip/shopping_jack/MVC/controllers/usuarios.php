<?php

	class usuarioscontroller {

		public function __construct(){
			require_once "models/usuariosModel.php";
		}

		public function index(){
			require_once "models/usuariosModel.php";
			$usuarios = new usuarios_model();
			$data["titulo"] = "usuarios";
			$data["Usuarios"] = $usuarios->get_usuarios();
			
			require_once "views/usuarios/usuarios.php";
		}

		public function nuevo(){
			
			$data["titulo"] = "usuarios";
			require_once "views/usuarios/usuarios_nuevo.php";
		}

		public function guarda(){
			
			$id_usuarios = $_GET['id_usuarios'];
			$nombre_us = $_POST['nombre_us'];
			$telefono = $_POST['telefono'];
			$correo = $_POST['correo'];
			$contrasena_B = $_POST['contrasena_B'];
			
			$usuarios = new usuarios_model();
			$usuarios->insertar($nombre_us, $telefono, $correo, $contrasena_B);
			$data["titulo"] = "usuarios";
			$this->index();
		}

		public function modificar($id_usuarios){
			
			$usuarios = new usuarios_model();
			
			$data["id_usuarios"] = $id_usuarios;
			$data["usuarios"] = $usuarios->get_usuarios($id_usuarios);
			$data["titulo"] = "usuarios";
			require_once "views/usuarios/usuarios_modifica.php";
		}

		public function actualizar(){

			$id_usuarios = $_POST['id_usuarios'];
			$nombre_us = $_POST['nombre_us'];
			$telefono = $_POST['telefono'];
			$correo = $_POST['correo'];
			$contrasena_B = $_POST['contrasena_B'];

			$usuarios = new usuarios_model();
			$usuarios->modificar($id_usuarios, $nombre_us, $telefono, $correo, $contrasena_B);
			$data["titulo"] = "usuarios";
			$this->index();
		}

		public function eliminar($id_usuarios){
			
			$usuarios = new usuarios_model();
			$usuarios->eliminar($id_usuarios);
			$data["titulo"] = "usuarios";
			$this->index();
		}	
		

	}

?>