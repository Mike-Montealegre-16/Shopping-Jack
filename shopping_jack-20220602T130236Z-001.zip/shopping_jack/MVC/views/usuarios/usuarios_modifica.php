<?php
	
?>

<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title><?php echo $data["titulo"]; ?></title>
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<script src="assets/js/bootstrap.min.js" ></script>
	</head>
	
	<body>
		<div class="container">
			
			<h2><?php echo $data["titulo"]; ?></h2>
			
			<form id="nuevo" name="nuevo" method="POST" action="index.php?c=usuarios&a=actualizar" autocomplete="off">
				
				<input type="hidden" id="id_usuarios" name="id_usuarios" value="<?php echo $data["id_usuarios"]; ?>" />
				
				<div class="form-group">
					<label for="nombre_us">Nombre</label>
					<input type="text" class="form-control" id="nombre_us" name="nombre_us" value="<?php if(isset($_GET['nombre_us'])) echo $_GET["nombre_us"];?>" />
				</div>
				
				<div class="form-group">
					<label for="telefono">Telefono</label>
					<input type="text" class="form-control" id="telefono" name="telefono" value="<?php if(isset($_GET['telefono'])) echo $_GET["telefono"];?>" />
				</div>
				
				<div class="form-group">
					<label for="correo">Correo</label>
					<input type="text" class="form-control" id="correo" name="correo" value="<?php if(isset($_GET['correo'])) echo $_GET["correo"];?>" />
				</div>
				
				<div class="form-group">
					<label for="contrasena_B">Contraseña</label>
					<input type="text" class="form-control" id="contrasena_B" name="contrasena_B" value="<?php if(isset($_GET['contrasena_B'])) echo $_GET["contrasena_B"];?>" />
				</div>
				
				<button id="guardar" name="guardar" type="submit" class="btn btn-primary">Guardar</button>
				
			</form>
		</body>
	</html>		