<?php

    include 'conexion.php';
 
    $nombre_us = $_POST['nombre_us'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $contrasena_B = $_POST['contrasena_B'];
    
    /*$contrasena_B = hash('md5', $contrasena_B);*/

    $query = "INSERT INTO usuarios(id_usuarios, nombre_us, telefono, correo, contrasena_B) VALUES('','$nombre_us','$telefono','$correo','$contrasena_B')";

    $verififcar_correo = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo='$correo'");

    if(mysqli_num_rows($verififcar_correo) > 0){
        echo'
            <script>
                alert("Este Correo Ya Esta Registrado, Intenta Con Otro Diferente");
                window.location = "../index_registro.php";
            </script>
        ';
        exit();
    }

    $ejecutar = mysqli_query($conexion, $query);

    if($ejecutar){
        echo '
            <script>
                alert("Usuario Almacenado Exitosamente");
                window.location = "administrador.php";
            </script>
        ';
    }else{
        echo '
            <script>
                alert("Intentalo De Nuevo, Usuario No Almacenado");
                window.location = "index_registro.php";
            </script>
        ';
    }

    mysqli_close($conexion);

?>