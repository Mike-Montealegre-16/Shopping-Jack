<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos_principal.css?2020">
    <title>Shopping Jack</title>
    <link rel="shortcut icon" href="../img_wellness/logowellnessfondonegro.jpeg" type="image/x-icon">
    <link async href="https://fonts.googleapis.com/css?family=Warnes" data-generated="http://enjoycss.com" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link href="../footer.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../js/header.js"></script>
    <link rel="stylesheet" href="index_contactanos.php">
    <link rel="stylesheet" href="index_inicio.php">
</head>
 <body>

    <header>
      <center>
        <div id="links">
          <a href="index_inicio.php">Iniciar sesión</a>
          <a href="index_registro.php">Aserca de nosotros</a>
          <a href="index_contactanos.php">Contáctenos</a>
        </div>
      </center>
    </header>

    <div id="header" class="animated slideInDown" style="animation-delay:1.8s;">
      <div id="button" >
        <h1 id="body">Shopping Jack</h2>
      </div>

    </div>
    <center>
      <div id="middle">
          <div id="tagline" class="animated zoomIn" style="animation-delay:1.8s;">
          <p>
              "No se trata de la talla que uses, sino de crear tu propia talla"
           </p>
          </div>
      </div>
    </center>
    <div id="portfolio">
        <div id="skills">
            <h2>Bienvenidos</h1>   
            <div>
                   <p>
                    Te ofrecemos todo lo relacionado con organización virtual y facilidades de uso para que logres tener el orden administrativo soñado,algunos de estos son:             
                   </p>
            </div> 
        </div>
         
        <div class="rainbow">Productos<img class="pimg" src="../img_wellness/ventas3.png" ></div>
        <div class="rainbow" id="position">Inventario <img class="pimg" src="../img_wellness/productos3.png" ></div>
        <div class="rainbow"id="position2">Empleados<img class="pimg" src="../img_wellness/inventario3.png" ></div>
        <div class="rainbow" id="position3">Bodegas<img class="pimg" src="../img_wellness/farmacia3.png" ></div>
        
        <div class="b-example-divider"></div>
<div id="footer">
  <div class="container">
    <footer class="row row-cols-1 row-cols-sm-2 row-cols-md-5 py-5 my-5 border-top">
      <div class="col mb-3">
        <a href="/" class="d-flex align-items-center mb-3 link-dark text-decoration-none">
          <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"/></svg>
        </a>

      <div class="col mb-3">
        <h5>Section</h5>
        <ul class="nav flex-column">
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Home</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Features</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Pricing</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">FAQs</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">About</a></li>
        </ul>
      </div>
    </footer>
  </div>

</div>
<script src="../js/index_principal.js" type="text/javascript"></script>
   
 </body>
 </html>