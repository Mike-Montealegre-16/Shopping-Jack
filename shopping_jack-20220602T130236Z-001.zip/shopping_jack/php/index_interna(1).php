<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/principal_interna.css?2021">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" charset="utf-8"></script>
    
    <link rel="shorcut icon" href="../img_wellness/logowellnessfondonegro.jpeg">
    <link rel="stylesheet" href="../js_wellness/script_principal_interna.js">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Acme&family=Lobster&family=Signika:wght@300&family=Stick+No+Bills:wght@300&family=Teko:wght@300&family=Vollkorn&display=swap" rel="stylesheet">
    
        <title>Página Principal</title>
</head>
<header class="header">
    <div class="container">
    <div class="btn-menu">
        <label for="btn-menu"></label>
    </div>
        <div class="logo">
            <h1></h1>
        </div>
        <nav class="menu">
            <a href="index_principal_interna.php">Inicio</a>
            <a href="contactanos_interna.php">Contacto</a>
            <a href="user_sessions.php">Cerrar sesion</a>
        </nav>
    </div>
</header>


<div class="menu-btn">
    <i class="fa-solid fa-bars"></i>
</div>
<div class="side-bar">
    <div class="close-btn">
        <i class="fa-solid fa-lock"></i>
    </div>
        <div class="menu">
            <h1 class="text"> Menu Administrativo </h1>
            <div class="item">
                <a class="sub-btn"><i class="fa-solid fa-dollar-sign"></i>Admistracion de usuarios<i class="fa-solid fa-angle-right dropdown"></i></a>
                <div class="sub-menu">
                    <a href="Admionistrador.php" class="sub-item">Usuarios</a>
                </div>
            </div>
            <div class="item">
                <a class="sub-btn"><i class="fa-brands fa-accusoft"></i>Administrar Bodegas<i class="fa-solid fa-angle-right dropdown"></i></a>
                <div class="sub-menu">
                    <a href="Admionistrador.php" class="sub-item">Bodega</a>
                </div>
            </div>
            <div class="item">
                <a class="sub-btn"><i class="fa-brands fa-firstdraft"></i>Administrar catalogos<i class="fa-solid fa-angle-right dropdown"></i></a>
                <div class="sub-menu">
                    <a href="Admionistrador.php" class="sub-item">catalogos</a>
                </div>
            </div>
           
        </div>

    </div>

    <section class="main">
        <h1><br>Shopping jack</h1>
    </section>
        
        <script type="text/javascript">
            $(document).ready(function(){
                //jquery for toggle sub menus
                $('.sub-btn').click(function(){
                    $(this).next('.sub-menu').slideToggle();
                    $(this).find('.dropdown').toggleClass('rotate');
                });

                //jquery for expand and collapse the sidebar
                $('.menu-btn').click(function(){
                    $('.side-bar').addClass('active');
                    $('.menu.btn').css("visibility", "hidden");
                });

                $('.close-btn').click(function(){
                    $('.side-bar').removeClass('active');
                    $('.menu.btn').css("visibility", "visible");
                });

            });
        </script>

</body>
</html>