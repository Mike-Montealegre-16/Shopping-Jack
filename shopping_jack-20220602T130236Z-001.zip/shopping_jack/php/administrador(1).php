<!DOCTYPE html>
<meta charset="UTF-8">
<meta>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap5.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />

<?php
    include('HEADER.php');
    include 'conexion.php';
?>
<head>
    <title>administrador</title>
</head>
<body>
    <br>
    <br>
    <a href="index_registro.php" class="btn btn-success"><i class="fas fa-user-plus"></i></a>
    <br>
    <br>
    <table width="500" border ="2" class="table table-dark table-striped">
        <thead class="thead thead-dark">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Telefono</th>
                <th>Correo</th>
                <th>Contraseña</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>
        </thead>

        <?php
            $consulta = "SELECT * FROM usuarios";
            $ejecutar =mysqli_query($conexion, $consulta);
            $i=0;
            while($fila = mysqli_fetch_array($ejecutar)){
        ?>
            <tr>
                <td><?php echo $fila['id_usuarios'] ?></td>
                <td><?php echo $fila['nombre_us'] ?></td>
                <td><?php echo $fila['telefono'] ?></td>
                <td><?php echo $fila['correo'] ?></td>
                <td><?php echo $fila['contrasena_B'] ?></td>
                <td>
                    <a href="editar.php?id=<?php echo $fila['id_usuarios'] ?>" class="btn btn-primary">
                        <i class="fas fa-user-edit"></i>
                    </a>
                </td>
                <td>
                    <a href="eliminar.php?id=<?php echo $fila['id_usuarios']?>" class="btn btn-danger">
                        <i class="fas fa-user-minus"></i>
                    </a>
                </td>
                
            </tr>
        <?php $i++;
            }
            include('FOOTER.php')  
        ?>


    </table>
</body>
</html>