<?php
    include 'conexion.php';

    if (isset($_GET['id_usuarios'])){
        $id_usuarios=$_GET['id_usuarios']; 
        $query="DELETE FROM usuarios where id_usuarios = $id_usuarios";
        $resultado= mysqli_query($conexion, $query);
        if ($resultado){
            echo("Usuario Eliminado");
        }else{
            echo("No se pudo Eliminar el Usuario");
        }

        header('location: administrador.php');
    }
?>