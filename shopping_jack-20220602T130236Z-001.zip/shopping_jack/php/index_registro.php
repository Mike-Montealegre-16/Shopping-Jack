<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wellness</title>
    <link rel="stylesheet" href="../css/estilos_registro.css">
    <link rel="shortcut icon" href="../img_wellness/logowellnessfondonegro.jpeg" type="image/x-icon">
</head>
<body>
    <section class="registro">
        <form action="conexion_registro.php" method="POST" class="form-register" onsubmit="returnvalidar();">
            <input class="entrada" type="text" name="nombre_us" required id="nombres" placeholder="Ingrese su Nombre">
            <input class="entrada" type="text" name="telefono" required id="telefono" placeholder="Ingrese su Telefono">
            <input class="entrada" type="email" name="correo" required id="correo" placeholder="Ingrese su correo">
            <input class="entrada" type="password" name="contrasena_B" required id="password" placeholder="Ingrese su Contraseña">
            <br>
            <br>
            <label class="i-checks">
                <input id="terms-new-client" name="new-client-terms" required type="checkbox"><i></i>
                Acepto <u><strong><a href="#">Términos y condiciones</a></strong></u>
            </label>
            <br>
            <br>
            <a href="administrador.php"><input class="button" type="submit" value="Registrar"></a>
            <p><a href="administrador.php">Regresar</a></p>
            <p class="warnings" id="warnings"></p>
        </form>
        <script src="app.js"></script>
    </section>
</body>
</html>