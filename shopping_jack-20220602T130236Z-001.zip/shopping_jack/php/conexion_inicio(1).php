<?php

session_start();
include 'conexion.php'; 

$correo = $_POST ['correo'];
$contrasena = $_POST ['contrasena'];
$administrador = mysqli_query ( $conexion , " SELECT * FROM usuarios where correo = '$correo'");

if($buscador = mysqli_fetch_assoc($administrador)){
if($contrasena == $buscador['contrasena_A']){
    $_SESSION ['id_usuarios'] = $buscador ['id_usuarios'];
    $_SESSION ['nombre_us'] = $buscador ['correo'];
echo '<script>alert ("Haz entrado al administrador")</script>';
echo '<script>window.location="administrador.php"</script>';
}
}

$administrador2 = mysqli_query( $conexion , " SELECT * FROM usuarios where correo = '$correo'");

if($buscador2 = mysqli_fetch_assoc($administrador2)){
    if($contrasena == $buscador2['contrasena_B']){
        $_SESSION ['id_usuarios'] = $buscador2 ['id_usuarios'];
        $_SESSION ['nombre_us'] = $buscador2 ['correo'];

echo '<script>window.location="index_interna.php"</script>';
    
}else{
    echo '<script>alert ("Usuario incorrecto")</script>';
    echo '<script>window.location="index_inicio.php"</script>';
}
}
?>