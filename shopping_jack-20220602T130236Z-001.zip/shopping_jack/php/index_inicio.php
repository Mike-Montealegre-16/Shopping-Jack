<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link rel="stylesheet" href="../css/estilos_inicio.css">
    <!--<link rel="shortcut icon" href="../img_wellness/logowellnessfondonegro.jpeg" type="image/x-icon">   imagen pequeña-->
</head>
<body>
<div class="login-page">
  <div class="form">
    <form action="conexion_inicio.php" class="login-form" method="POST">
      <input class= "tex" type="email" name="correo"  id="correo" required placeholder="Ingrese su Correo"/>
      <input class= "tex" type="password" name="contrasena" required id="contrasena" placeholder="Ingrese su Contraseña"/>
      <a href="C:\xampp\htdocs\shopping_jack\php/administrador.php"><input class="button" type="submit" value="Iniciar"></a>
      <br>
      <a href="restablecer.php" class="message">¿Olvidate tu contraseña?</a>
    </form>
  </div>
</div>
</body>
</html>