<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Dato</title>
    <link rel="stylesheet" href="../css/estilos_editar.css">
    <link rel="shortcut icon" href="../img_wellness/logowellnessfondonegro.jpeg" type="image/x-icon">
</head>
<body>

<?php
include 'conexion.php';
include('HEADER.php');
if (isset($_GET['id_usuarios'])){
    $id_usuarios=$_GET['id_usuarios'];
    $query = "SELECT * FROM usuarios where id_usuarios=$id_usuarios";
    $resultado= mysqli_query($conexion, $query);
        if(mysqli_num_rows($resultado)==1){
    
        $resul=mysqli_fetch_array($resultado);
        $nombre_us= $resul['nombre_us'];
        $telefono=$resul['telefono'];
        $contrasena_B=$resul['contrasena_B'];
        $correo=$resul['correo'];
    }}
if (isset($_POST['editar'])){
    $id_usuarios = $_GET ['id_usuarios'];
    $nombre_us = $_POST ['nombre_us'];
    $telefono = $_POST ['telefono'];
    $contrasena_B = $_POST ['contrasena_B'];
    $correo = $_POST ['correo'];
    $query="UPDATE usuarios SET nombre_us='$nombre_us', telefono='$telefono', contrasena_B='$contrasena_B', correo='$correo' WHERE id_usuarios=$id_usuarios";

    mysqli_query($conexion, $query);
    header ("location: administrador.php");
}
?>
<div>
    <section class="registro">
        <form action="editar.php? id_usuarios=<?php echo $_GET ['id_usuarios']; ?>"method="POST" class="form-register" onsubmit="returnvalidar();">
            <input type="hidden" name="id_usuarios" value="<?php echo $id_usuarios ?>">
            <input class="entrada" type="text" placeholder="Ingrese nombre" required name="nombre_us" value="<?php echo $nombre_us ?>">
            <input class="entrada" type="text" placeholder="Ingrese el telefono" required name="telefono" value="<?php echo $telefono ?>">
            <input class="entrada" type="email" placeholder="Ingrese correo" required name="correo" value="<?php echo $correo ?>">
            <input class="entrada" type="text" placeholder="Ingrese contraseña" required name="contrasena_B" value="<?php echo $contrasena_B ?>">
            <br>
            <center>
                <input type="submit" class="button" name="editar" value="Actualizar">
                <br>
                <a href="administrador.php">Regresar</a>
            </center>
        </form>
    </section>
</div>
</body>
</html>