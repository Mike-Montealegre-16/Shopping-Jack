-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-06-2022 a las 23:21:38
-- Versión del servidor: 10.4.19-MariaDB
-- Versión de PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `shopping_jack`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bodegas`
--

CREATE TABLE `bodegas` (
  `id_bodega` int(11) NOT NULL,
  `nom_bodega` varchar(50) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `cede_bodega` varchar(50) NOT NULL,
  `cod_producto` int(11) DEFAULT NULL,
  `id_materia_prima` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `bodegas`
--

INSERT INTO `bodegas` (`id_bodega`, `nom_bodega`, `direccion`, `cede_bodega`, `cod_producto`, `id_materia_prima`) VALUES
(1, 'Taller_1', 'KRA 82C #51B 23SUR', 'Shopping_Jack_1', NULL, NULL),
(2, 'Taller_2', 'Transversal 7 #58H 29 SUR', 'Shopping_Jack_2', NULL, NULL),
(3, 'Taller_3', 'Calle 49A #33C 18 NORTE', 'Shopping_Jack_3', NULL, NULL),
(4, 'Oficinas_Shopping_Jack', 'KRA 24D #31C 33', 'Shopping_Jack_Oficinas', NULL, NULL),
(5, 'Taller_4', 'Calle 42K #22-33 ', 'Shopping_Jack_4', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia_prima`
--

CREATE TABLE `materia_prima` (
  `id_materia_prima` int(11) NOT NULL,
  `categoria_mp` varchar(100) NOT NULL,
  `descripcion_mp` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `materia_prima`
--

INSERT INTO `materia_prima` (`id_materia_prima`, `categoria_mp`, `descripcion_mp`) VALUES
(1, 'Telas', '100 metros de telas antifluido de color gris ratón.\r\n'),
(2, 'Botones', '7 docenas de botón para jean mediano color ocre\r\n'),
(3, 'Hilos', '5 Docenas de hilo color caqui 120 de 2000Y.'),
(4, 'Botones', '100 Broches para chaqueta beisbolera color negro'),
(5, 'Telas', '50 metros de tela cerro sport azul petróleo.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `cod_producto` int(11) NOT NULL,
  `nombre_prod` varchar(50) NOT NULL,
  `precio_un` double NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `cantidad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`cod_producto`, `nombre_prod`, `precio_un`, `tipo`, `cantidad`) VALUES
(1, 'Camiseta', 30000, 'Sport', NULL),
(2, 'Jean', 68000, 'Elegante', NULL),
(3, 'Camisa', 28000, 'Elegante', NULL),
(4, 'Sudadera', 20000, 'Sport', NULL),
(5, 'Chaqueta', 50000, 'Beisbolera', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuarios` int(11) NOT NULL,
  `nombre_us` varchar(50) NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `contrasena_B` varchar(100) NOT NULL,
  `contrasena_A` varchar(100) NOT NULL,
  `id_bodega` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuarios`, `nombre_us`, `telefono`, `correo`, `contrasena_B`, `contrasena_A`, `id_bodega`) VALUES
(1, 'Administrador', '3213488570', 'shoppingjack@gmail.com', '', 'admin', 1),
(2, 'Manuel Galindo', '31224447889', 'juan@gmail.com', '$2y$10$MHOBm52iPaPDfWMy68I3NuVP9TLVoGrV/7JnEH38GG2HaIeUHfEu6', '', 5),
(3, 'Orlando mora', '3015478964', 'omora66@gmail.com', '$2y$10$7xfYmT6XEONC92jiYIL29OhpM.vjjZ80lUX7/ChvCMbSDcHIQNH5m', '', 2),
(4, 'Alison Becerra', '3124560028', 'anbecerra61@gmail.com', '$2y$10$8oKHn8AO0ImrzfyfxdsMg.6b.kIVMPjq4C.kyX9Jyypb26NN9vRvO', '', 3),
(5, 'Andres Supelano', '3216547894', 'manuela2022@gmail.com', '$2y$10$DDcS8WNBszeuAtGoSxCUVePeBXccgrw1lbOKzlsxvVsaa4HW9xCWG', '', 5),
(7, 'Felipe', '1223654646', 'felipe@gmail.com', '$2y$10$E1D0hC0bnbTPWXEoSLd35.BuZVuXlNcAAcN5T/W6aqoat2fUAUpEK', '', 3),
(8, 's', 's', 's@gmail.com', '$2y$10$CcmQDjN/ARA1iFwq8kRdKOj1wBM7.gIS5bfOqZkBX/ecT.8d9rKHy', '', 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bodegas`
--
ALTER TABLE `bodegas`
  ADD PRIMARY KEY (`id_bodega`),
  ADD KEY `cod_producto` (`cod_producto`),
  ADD KEY `id_materia_prima` (`id_materia_prima`);

--
-- Indices de la tabla `materia_prima`
--
ALTER TABLE `materia_prima`
  ADD PRIMARY KEY (`id_materia_prima`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`cod_producto`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuarios`),
  ADD KEY `id_bodega` (`id_bodega`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bodegas`
--
ALTER TABLE `bodegas`
  MODIFY `id_bodega` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `materia_prima`
--
ALTER TABLE `materia_prima`
  MODIFY `id_materia_prima` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `cod_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuarios` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `bodegas`
--
ALTER TABLE `bodegas`
  ADD CONSTRAINT `cod_producto` FOREIGN KEY (`cod_producto`) REFERENCES `productos` (`cod_producto`),
  ADD CONSTRAINT `id_materia_prima` FOREIGN KEY (`id_materia_prima`) REFERENCES `materia_prima` (`id_materia_prima`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `id_bodega` FOREIGN KEY (`id_bodega`) REFERENCES `bodegas` (`id_bodega`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
