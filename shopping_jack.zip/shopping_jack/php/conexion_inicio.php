<?php

session_start();
include 'conexion.php'; 

$correo = $_POST ['correo'];
$contrasena = $_POST ['contrasena'];
$administrador = mysqli_query ( $conexion , " SELECT * FROM usuarios where correo = '$correo'");

if($buscador = mysqli_fetch_assoc($administrador)){
if($contrasena == $buscador['contrasena_A']){
    $_SESSION ['id_usuarios'] = $buscador ['id_usuarios'];
    $_SESSION ['nombre_us'] = $buscador ['correo'];
echo '<script>alert ("Haz entrado al administrador")</script>';
echo '<script>window.location="../MVC"</script>';
}
}



if(isset($_POST['inicio']))
{
    $administrador2 = mysqli_query( $conexion , " SELECT * FROM usuarios where correo = '$correo'");
    $nr = mysqli_num_rows($administrador2);
    $buscarcon = mysqli_fetch_array($administrador2);
    if(($nr == 1) && (password_verify($contrasena, $buscarcon['contrasena_B']))){

echo '<script>window.location="index_interna.php"</script>';
    
}else{
    echo '<script>alert ("Usuario incorrecto")</script>';
    echo '<script>window.location="index_inicio.php"</script>';
}
}
?>