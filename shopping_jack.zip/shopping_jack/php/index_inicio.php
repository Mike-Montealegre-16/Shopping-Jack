<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <style type="text/css">input::placeholder {color: #fff}</style>
    <link rel="stylesheet" href="../css/estilos_inicio.css?2465">
    <link rel="shortcut icon" href="../img/logo_morado.png" type="image/x-icon">
</head>
<body>
<div class= "titulo"><center><h2>Shopping Jack</h2></center></div>
<div class="login-page">
  <div class="form">
    <form action="conexion_inicio.php" class="login-form" method="POST">
    <h1><p> Iniciar Sesión</p></h1>
      <input class= "text" type="email" name="correo"  id="correo" required placeholder="Ingrese su Correo"/>
      <input class= "text" type="password" name="contrasena" required id="contrasena" placeholder="Ingrese su Contraseña"/>
      <a href="C:\xampp\htdocs\shopping_jack\php/administrador.php"><input class="button" type="submit" name="inicio" value="Iniciar"></a>
      <br>
      <a href="restablecer.php" class="message">¿Olvido su contraseña?</a>
    </form>
  </div>
</div>
</body>
</html>