<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title><?php echo $data["titulo"]; ?></title>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap5.min.css">
        <link rel="shortcut icon" href="../img/logo_morado.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />

<?php
    include('../php/HEADER.php');
    include '../php/conexion.php';
?>
		<script src="assets/js/bootstrap.min.js" ></script>
	</head>
	
	<body>
		<div class="container">
			<h2><?php echo $data["titulo"]; ?></h2>
            <a href="index.php?c=usuarios&a=nuevo" class="btn btn-success"><i class="fas fa-user-plus"></i></a>
			
			<br />
			<br />

			<div class="table-responsive">
                <table width="11500" border ="2" class="table table-dark table-striped">
					<thead>
						<tr class="table-primary">
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Telefono</th>
                            <th>Correo</th>
                            <th>Contraseña</th>
                            <th>Bodegas</th>
                            <th>Editar</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>

                     <tbody>
            <?php foreach($data["Usuarios"] as $dato) {
                echo "<tr>";
                echo "<td>".$dato["id_usuarios"]."</td>";
                echo "<td>".$dato["nombre_us"]."</td>";
                echo "<td>".$dato["telefono"]."</td>";
                echo "<td>".$dato["correo"]."</td>";
                echo "<td>".$dato["contrasena_B"]."</td>";
                echo "<td>".$dato["id_bodega"]."</td>";
                echo "<td><a href='index.php?c=usuarios&a=modificar&id_usuarios=".$dato["id_usuarios"]."' class='btn btn-primary'><i class='fas fa-user-edit'></i></a></td>";
                
                echo "<td><a href='index.php?c=usuarios&a=eliminar&id_usuarios=".$dato["id_usuarios"]."' class='btn btn-danger'><i class='fas fa-user-minus'></i></a></td>";

                echo "</tr>";
            }
            ?>
				    </tbody>
					
                </table>
            </div>

        </div>
    </body>
</html>