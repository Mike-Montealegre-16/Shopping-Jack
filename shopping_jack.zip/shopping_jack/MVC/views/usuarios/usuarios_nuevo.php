<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title><?php echo $data["titulo"]; ?></title>
    <style type="text/css">input::placeholder {color: white} </style>
    <link rel="stylesheet" href="../css/estilos_registro.css?2231">
    <link rel="shortcut icon" href="../img/logo_morado.png" type="image/x-icon">
    <script src="assets/js/bootstrap.min.js" ></script>
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
</head>
<body>
    <div class="titulo">
        <h2>Shopping Jack</h2>
    </div>
        <div>
            <section class="registro">
                <form id="nuevo" name="nuevo" method="POST" action="index.php?c=usuarios&a=guarda" autocomplete="off">
                    <center><h1>Registrar Información</h1></center>
                    <input class="entrada" type="text" name="nombre_us" required id="nombres"  placeholder="Ingrese su Nombre">
                    <input class="entrada" type="text" name="telefono" required id="telefono" placeholder="Ingrese su Telefono">
                    <input class="entrada" type="email" name="correo" required id="correo" placeholder="Ingrese su Correo">
                    <input class="entrada" name="password" required placeholder="Ingrese su contraseña" id="password" type="password" />
                    <input class="entrada" type="password" name="contrasena_B" required placeholder="Verifique su contraseña" id="confirm_password" />
                    <span id='message'></span>
                    <!-- <input class="entrada" type="text" name="id_bodega" required id="id_bodega" placeholder="Ingrese la Bodega" > -->

                        <select class="opcion" required name="id_bodega" id="id_bodega">
                            <option value="0">Seleccione Bodega</option>
                            <option value="1">Taller_1</option>
                            <option value="2">Taller_2</option>
                            <option value="3">Taller_3</option>
                            <option value="4">Oficinas_Shopping_Jack</option>
                            <option value="5">Taller_4</option>
                        </select>


                    <script>
                    $('#password, #confirm_password').on('keyup', function () {
                    if ($('#password').val() == $('#confirm_password').val()) {
                     $('#message').html('Coincide').css('color', 'green');
                     } else 
                          $('#message').html('No Coincide').css('color', 'red');    
                    });
                    </script>


                    <a href="index.php"><input id="guardar" class="button" type="submit" value="Registrar"></a>
                    <center>
                        <p><a href="index.php">Regresar</a></p>
                    </center>
                    <p class="warnings" id="warnings"></p>
                </form>
                <script src="app.js"></script>
            </section>
        </div>
</body>
</html>