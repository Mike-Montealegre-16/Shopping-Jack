<?php

	class usuarioscontroller {

		public function __construct(){
			require_once "models/usuariosModel.php";
		}

		public function index(){
			require_once "models/usuariosModel.php";
			$usuarios = new usuarios_model();
			$data["titulo"] = "usuarios";
			$data["Usuarios"] = $usuarios->get_usuarios();
			
			require_once "views/usuarios/usuarios.php";
		}

		public function nuevo(){
			
			$data["titulo"] = "usuarios";
			require_once "views/usuarios/usuarios_nuevo.php";
		}

		public function guarda(){
			
			/*$id_usuarios = $_GET['id_usuarios'];*/
			$nombre_us = $_POST['nombre_us'];
			$telefono = $_POST['telefono'];
			$correo = $_POST['correo'];
			$contrasena_B = $_POST['contrasena_B'];
			$id_bodega = $_POST['id_bodega'];
			$encriptada = password_hash($contrasena_B, PASSWORD_DEFAULT);
			
			$usuarios = new usuarios_model();
			$usuarios->insertar($nombre_us, $telefono, $correo, $encriptada, $id_bodega);
			// if(mysqli_query ($conexion,$usuarios))
			// {
			// 	echo "<script>alert('Usuario $nombre_us registrado');window.location='index.php'</script>";
			// }else
			// {
			// 	echo "Error: ".$usuarios."<br>".mysql_error($conexion);
			// }
			$data["titulo"] = "usuarios";
			$this->index();
		}

		public function modificar($id_usuarios){
			
			$usuarios = new usuarios_model();
			
			$data["id_usuarios"] = $id_usuarios;
			$data["usuarios"] = $usuarios->get_usuario($id_usuarios);
			$data["titulo"] = "usuarios";
			require_once "views/usuarios/usuarios_modifica.php";
		}

		public function actualizar(){

			$id_usuarios = $_POST['id_usuarios'];
			$nombre_us = $_POST['nombre_us'];
			$telefono = $_POST['telefono'];
			$correo = $_POST['correo'];
			$contrasena_B = $_POST['contrasena_B'];
			$id_bodega = $_POST['id_bodega'];

			$usuarios = new usuarios_model();
			$usuarios->modificar($id_usuarios, $nombre_us, $telefono, $correo, $contrasena_B, $id_bodega);
			$data["titulo"] = "usuarios";
			$this->index();
		}

		public function eliminar($id_usuarios){
			
			$usuarios = new usuarios_model();
			$usuarios->eliminar($id_usuarios);
			$data["titulo"] = "usuarios";
			$this->index();
		}	
		

	}

?>