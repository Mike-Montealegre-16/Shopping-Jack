<?php

	class conectar {
		public static function conexion(){

			$conexion = new mysqli("localhost", "root", "", "shopping_jack");
			return $conexion;
		}
	}
?>