<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos_bodegas.css?2002">
    <link rel="shortcut icon" href="../img/logo_morado.png" type="image/x-icon">
    <title>Bodegas</title>
</head>
<body>
    
</body>
</html>