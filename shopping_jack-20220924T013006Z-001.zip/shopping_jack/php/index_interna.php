<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/principal_interna.css?2011">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" charset="utf-8"></script>
    
    <link rel="shortcut icon" href="../img/logo_morado.png" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Acme&family=Lobster&family=Signika:wght@300&family=Stick+No+Bills:wght@300&family=Teko:wght@300&family=Vollkorn&display=swap" rel="stylesheet">
<!-- Logotipos del footer -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
<!-- Logotipos del footer -->
<!--stylesheet -->
<link href="https://fonts.googleapis.com/css2?family=Courgette&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
<link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<!--stylesheet -->

        <title>Página Principal</title>
</head>
<header class="header">
    <div class="container">
    <div class="btn-menu">
        <label for="btn-menu"></label>
    </div>
        <div class="logo">
            <h1></h1>
        </div>
        <nav class="menu">
            <a href="../index.html">Cerrar sesion</a>
        </nav>
    </div>
</header>


    <section class="main">
        <h1><br>Shopping Jack</h1>
    </section>
    
    <div class="section">
            <div class="boton_usuarios" href="../MVC/index.php">
                <img src=../img/Usuarios.jpg>
                <a href="../MVC/index.php"></a>
                <div class="hover">
                    <a href="../MVC/index.php" style="text-decoration:none;"><h1>Usuarios</h1></a>
                </div>
            </div>

            <div class="boton_bodegas">
                <img src=../img/Bodegas.jpg>
                <div class="hover">
                <a href="../php/bodegas.php" style="text-decoration:none;"><h1>Bodegas</h1></a>  
            </div>
        </div>
        </div>    
        <div class="section">
        <div class="boton_materia_prima">
            <img src=../img/Materia_Prima.jpg>
            <div class="hover">
            <a href="../php/materia_prima.php" style="text-decoration:none;">
                <h1><p>Materia <br>
                Prima</p></h1></a>
            </div>
        </div>

        <div class="boton_productos">
            <img src=../img/Productos.jpg>
            <div class="hover">
            <a href="../php/productos.php" style="text-decoration:none;"><h1>Productos</h1></a>
            </div>
        </div>
        </div>
        <footer>
    <div class="footer-content">
      <h2>Shopping Jack</h2>
      <p>Somos la mejor opción para tí<br>Encuéntranos en el barrio Villa Andrea</p>
      <ul class="socials">
        <li><a href="https://www.facebook.com/pages/category/Local-service/Shopping-JACK-110729053964953/" target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a></li>
        <li><a href="#" target="_blank" title="Whatsapp"><i class="fa fa-whatsapp"></i></a></li>
      </ul>
    </div>
    <div class="footer-bottom">
      <p>copyright &copy; 2022 Shopping Jack. designed by <span>Nosotros</span></p>
    </div>
  </footer>
            <!--(../MVC/index.php) CONEXION CON EDICION DE USUARIOS-->
</body>
</html>