<head>
<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome,opera,safari,firefox">
        <meta name="viewport" content="width=device-width" initial-scale="1.0">
        <meta author="Catalina">
        <title>Administrador</title>
        <link rel="shortcut icon" href="../img_wellness/logowellnessfondonegro.jpeg" type="image/x-icon">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!--FONDO CSS -->
    <link rel="stylesheet" type="text/css" href="../css/estilos_crud.css?2220"> 
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous">
  </head>
  <body>
  <nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a href="index.php" class="navbar-brand"><i></i>ADMINISTRADOR</a>
        <a href="../php/index_interna.php" class="navbar-brand">
        <i></i> VOLVER
        </a>
</nav>
  </body>