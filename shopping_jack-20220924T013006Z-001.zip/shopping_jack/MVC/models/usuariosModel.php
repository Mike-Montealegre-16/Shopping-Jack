<?php
	
	class usuarios_model  {
		
		private $db;
		private $usuarios;
		
		public function __construct(){
			$this->db = Conectar::conexion();
			$this->usuarios = array();
		}
		
		public function get_usuarios()
		{
			$sql = "SELECT * FROM usuarios";
			$resultado = $this->db->query($sql);
			while($row = $resultado->fetch_assoc())
			{
				$this->usuarios[] = $row;
			}
			return $this->usuarios;
		}
		
		public function insertar($nombre_us, $telefono, $correo, $contrasena_B, $id_bodega){
			
			$resultado = $this->db->query("INSERT INTO usuarios (nombre_us, telefono, correo, contrasena_B, id_bodega) VALUES ('$nombre_us', '$telefono', '$correo', '$contrasena_B', '$id_bodega')");
			
		}
		
		public function modificar($id_usuarios, $nombre_us, $telefono, $correo, $contrasena_B, $id_bodega){
			
			$resultado = $this->db->query("UPDATE usuarios SET nombre_us='$nombre_us', telefono='$telefono', correo='$correo', contrasena_B='$contrasena_B', id_bodega='$id_bodega' WHERE id_usuarios = '$id_usuarios'");			
		}
		
		public function eliminar($id_usuarios){
			
			$resultado = $this->db->query("DELETE FROM usuarios WHERE id_usuarios = '$id_usuarios'");
			
		}
		
		public function get_usuario($id_usuarios)
		{
			$sql = "SELECT * FROM usuarios WHERE id_usuarios='$id_usuarios' LIMIT 1";
			$resultado = $this->db->query($sql);
			$row = $resultado->fetch_assoc();

			return $row;
		}
	} 
?>