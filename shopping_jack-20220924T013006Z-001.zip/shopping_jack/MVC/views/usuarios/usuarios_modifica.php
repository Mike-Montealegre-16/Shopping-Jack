<?php

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $data["titulo"]; ?></title>
    <link rel="stylesheet" href="../css/estilos_editar.css?2100">
    <link rel="shortcut icon" href="../img/logo_morado.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<script src="assets/js/bootstrap.min.js" ></script>
</head>
<body>

<div>
    <section class="registro">
        <center>
        <h2>Editar</h2>
        <center>
            <br>
        <form id="nuevo" name="nuevo" action="index.php?c=usuarios&a=actualizar" method="POST" class="form-register" autocomplete="off">
        <input type="hidden" id="id_usuarios" name="id_usuarios" value="<?php echo $data["id_usuarios"]; ?>" />
            <div class="form-group">
				<input type="text" class="entrada" id="nombre_us" placeholder="Ingrese nombre" name="nombre_us" value="<?php echo $data["usuarios"]["nombre_us"]?>" />
			</div>
            <div class="form-group">
				<input type="text" class="entrada" id="telefono" placeholder="Ingrese telefono" name="telefono" value="<?php echo $data["usuarios"]["telefono"]?>" />
			</div>
            <div class="form-group">
				<input type="mail" class="entrada" id="correo" placeholder="Ingrese correo" name="correo" value="<?php echo $data["usuarios"]["correo"]?>" />
			</div>
            <div class="form-group">
				<input type="password" class="entrada" id="contrasena_B" placeholder="Ingrese contraseña" name="contrasena_B" value="<?php echo $data["usuarios"]["contrasena_B"] ?>"/>
			</div>
            <div class="form-group">
				<input type="text" class="entrada" id="id_bodega" placeholder="Ingrese la Bodega" name="id_bodega" value="<?php echo $data["usuarios"]["id_bodega"] ?>"/>
			</div>
            <center>
                <input id="guardar" type="submit" class="button" name="guardar" value="Actualizar">
                <br>
                <a href="index.php">Regresar</a>
            </center>
        </form>
    </section>
</div>
</body>
</html> |