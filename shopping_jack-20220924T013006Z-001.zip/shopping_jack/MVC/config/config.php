<?php
	
	define("CONTROLADOR_PRINCIPAL", "usuarios");
	define("ACCION_PRINCIPAL", "index");
	
?>